//to show password//
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
// to show confirm password//
function myFunction1() {
  var x = document.getElementById("password1");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
//to check whether password and confirm password is same or not//
function Validate() {
        var password = document.getElementById("password").value;
        var password1 = document.getElementById("password1").value;
        if (password != password1) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
function required()
{
var empt = document.forms["form1"]["text1"].value;
if (empt == "")
{
alert("Please input a Value");
return false;
}
else 
{
alert('Code has accepted : you can try another');
return true; 
}
}